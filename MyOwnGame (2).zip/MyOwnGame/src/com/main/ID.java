package com.main;

public enum ID {
    Player(),
    Enemy();

}
